package com.example.mysqlproject;

import android.widget.TextView;

public class HelpScreen {
}

TextView textView = findViewById(R.id.textView4)
        String text = "History"